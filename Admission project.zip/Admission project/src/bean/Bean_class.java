package bean;

public class Bean_class 
{
private int roll;
private String stname;
private String sclname;
private int mark12 ;
private int mark10;

public int getroll() {
	return roll;
}

public void setroll(int roll) {
	this.roll= roll;
}

public String getstname() {
	return stname;
}
public void setstname(String stname) {
	this.stname = stname;
}
public String getsclname() {
	return sclname;
}
public void setsclname(String sclname) {
	this.sclname = sclname;
}


public int getmark12() {
	return mark12;
}
public void setmark12(int mark12) {
	this.mark12=mark12;
}
public int getmark10() {
	return mark10;
}
public void setmark10(int mark10) {
	this.mark10=mark10;
}
public Bean_class()
{
	super();
}

}
